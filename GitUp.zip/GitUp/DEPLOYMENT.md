# Deploying to Render

This guide will help you deploy your Fake News Detector application to Render for free.

## Prerequisites

1. A GitHub account
2. Your code pushed to GitHub repository: `git@github.com:pingaponga9-cell/FilosofiaEducallis.git`
3. A free Render account (sign up at https://render.com)

## Deployment Steps

### Step 1: Push Your Code to GitHub

First, make sure all your code is on GitHub. Run these commands in the Shell:

```bash
# Add all files to git
git add .

# Commit your changes
git commit -m "Prepare for Render deployment"

# Push to GitHub
git push -u origin main
```

(If the branch is named "master", use `git push -u origin master` instead)

### Step 2: Create a Render Account

1. Go to https://render.com
2. Click "Get Started for Free"
3. Sign up with your GitHub account (recommended) or email

### Step 3: Deploy Your Application

1. **Connect Your GitHub Repository:**
   - On the Render dashboard, click "New +" → "Web Service"
   - Connect your GitHub account if you haven't already
   - Find and select the `FilosofiaEducallis` repository

2. **Configure the Service:**
   - **Name**: `filosofia-educallis` (or any name you prefer)
   - **Region**: Choose closest to your location
   - **Branch**: `main` (or `master` if that's your branch name)
   - **Root Directory**: Leave blank
   - **Runtime**: Node
   - **Build Command**: `npm install && npm run build`
   - **Start Command**: `npm start`
   - **Plan**: Free

3. **Environment Variables:**
   - Click "Advanced" to expand
   - Add environment variable:
     - Key: `NODE_ENV`
     - Value: `production`

4. **Click "Create Web Service"**

### Step 4: Wait for Deployment

- Render will automatically build and deploy your application
- This usually takes 3-5 minutes for the first deployment
- You can watch the build logs in real-time

### Step 5: Access Your Application

Once deployment is complete:
- Your app will be live at: `https://filosofia-educallis.onrender.com` (or your chosen name)
- Render provides a free SSL certificate automatically

## Important Notes

### Free Tier Limitations

- **Sleep Mode**: Your app will sleep after 15 minutes of inactivity
- **Wake Time**: First visit after sleeping takes ~30 seconds to wake up
- **Bandwidth**: 100 GB/month
- **Build Time**: 500 hours/month

### Automatic Deployments

- Every time you push to your `main` branch on GitHub, Render will automatically rebuild and redeploy your app
- You can disable this in the Render dashboard if needed

## Troubleshooting

### Build Fails

If the build fails, check:
1. Build logs in Render dashboard for error messages
2. Make sure all dependencies are in `package.json`
3. Verify Node version is 20 (specified in `.node-version` file)

### App Doesn't Start

Check:
1. Start command is correctly set to `npm start`
2. Environment variable `NODE_ENV` is set to `production`
3. Logs in Render dashboard for error messages

### App Shows Error Page

Check the logs in Render dashboard:
- Click on your service
- Go to "Logs" tab
- Look for error messages

## Updating Your App

To update your deployed app:

```bash
# Make your changes
# Then commit and push:
git add .
git commit -m "Your update message"
git push
```

Render will automatically detect the changes and redeploy!

## Alternative: Manual Deploy (Without render.yaml)

If you prefer not to use the `render.yaml` file:

1. Delete `render.yaml` from your repository
2. Follow steps 1-5 above, manually entering all configuration
3. The result will be the same

## Cost

This deployment is **100% FREE** on Render's free tier. Perfect for:
- School projects
- Portfolio websites
- Personal projects
- Demos and prototypes

## Support

For more help:
- Render Documentation: https://render.com/docs
- Render Community: https://community.render.com
