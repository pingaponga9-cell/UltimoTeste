# 🚀 Quick Start: Deploy to Render in 5 Minutes

## What You Need
- Your code on GitHub (repository: FilosofiaEducallis)
- A free Render account

## Step-by-Step Instructions

### 1️⃣ Push Your Code to GitHub

Open the **Shell** in Replit and run:

```bash
git add .
git commit -m "Ready for Render deployment"
git push -u origin main
```

> If it asks about the branch, try `git push -u origin master` instead

### 2️⃣ Sign Up on Render

1. Go to: **https://render.com**
2. Click **"Get Started for Free"**
3. Sign up with your **GitHub account** (easiest option)

### 3️⃣ Create Your Web Service

1. On Render dashboard, click **"New +"** → **"Web Service"**
2. Click **"Connect GitHub"** (if not already connected)
3. Find and select **"FilosofiaEducallis"** repository
4. Fill in these settings:

   ```
   Name: filosofia-educallis
   Region: Oregon (or closest to you)
   Branch: main
   Build Command: npm install && npm run build
   Start Command: npm start
   Plan: Free
   ```

5. Click **"Create Web Service"**

### 4️⃣ Wait for Build

- Watch the build logs (takes 3-5 minutes)
- When you see "Live" with a green checkmark, you're done! ✅

### 5️⃣ Visit Your Live App

Your app will be at:
```
https://filosofia-educallis.onrender.com
```

## ⚠️ Important to Know

- **First visit takes 30 seconds** (app wakes from sleep)
- **Completely FREE** forever
- **Auto-updates** when you push to GitHub

## 🔄 To Update Your App

Just push to GitHub:
```bash
git add .
git commit -m "Updated app"
git push
```

Render automatically rebuilds and deploys! 🎉

## 📺 Video Tutorial (if needed)
Search YouTube for: "Deploy Node.js app to Render"

---

**That's it!** Your Fake News Detector will be live and accessible to anyone on the internet! 🌍
